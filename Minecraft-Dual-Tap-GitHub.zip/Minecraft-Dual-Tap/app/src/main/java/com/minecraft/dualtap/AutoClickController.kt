package com.minecraft.dualtap

/** Bridge between click requests and the running accessibility service. */
object AutoClickController {
    @Volatile var service: AutoClickService? = null

    val isConnected: Boolean get() = service != null

    fun tapAll(points: List<Pair<Float, Float>>) {
        service?.performTaps(points)
    }
}
