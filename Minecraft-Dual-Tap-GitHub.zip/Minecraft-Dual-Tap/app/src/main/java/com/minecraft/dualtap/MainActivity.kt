package com.minecraft.dualtap

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var settings: SettingsManager
    private lateinit var textStatus: TextView
    private lateinit var btnToggle: Button
    private lateinit var textCps: TextView
    private lateinit var textSize: TextView
    private lateinit var textAlpha: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        settings = SettingsManager(this)

        textStatus = findViewById(R.id.textStatus)
        btnToggle = findViewById(R.id.btnToggle)
        textCps = findViewById(R.id.textCps)
        textSize = findViewById(R.id.textSize)
        textAlpha = findViewById(R.id.textAlpha)

        findViewById<Button>(R.id.btnOverlay).setOnClickListener { PermissionManager.openOverlaySettings(this) }
        findViewById<Button>(R.id.btnAccess).setOnClickListener { AccessibilityController.openSettings(this) }
        btnToggle.setOnClickListener { toggleService() }
        findViewById<Button>(R.id.btnReset).setOnClickListener {
            settings.resetPositions(); OverlayService.instance?.applySettings()
        }

        val sw = findViewById<Switch>(R.id.switchVisible)
        sw.isChecked = settings.visible
        sw.setOnCheckedChangeListener { _, on -> settings.visible = on; OverlayService.instance?.applySettings() }

        bindSeek(R.id.seekCps, settings.cps - 1) { settings.cps = it + 1; updateLabels() }
        bindSeek(R.id.seekSize, settings.sizeDp - 40) { settings.sizeDp = it + 40; updateLabels() }
        bindSeek(R.id.seekAlpha, settings.alphaPct - 20) { settings.alphaPct = it + 20; updateLabels() }
        updateLabels()
    }

    private fun bindSeek(id: Int, value: Int, onChange: (Int) -> Unit) {
        val s = findViewById<SeekBar>(id)
        s.progress = value
        s.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) {
                if (fromUser) { onChange(p); OverlayService.instance?.applySettings() }
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {}
        })
    }

    private fun updateLabels() {
        textCps.text = "سرعة النقر: ${settings.cps} نقرة/ثانية"
        textSize.text = "حجم الدوائر: ${settings.sizeDp} dp"
        textAlpha.text = "الشفافية: ${settings.alphaPct}%"
    }

    private fun toggleService() {
        if (OverlayService.isRunning) {
            stopService(Intent(this, OverlayService::class.java))
        } else {
            if (!PermissionManager.canDrawOverlays(this)) {
                Toast.makeText(this, R.string.need_overlay, Toast.LENGTH_LONG).show(); return
            }
            if (!AccessibilityController.isServiceEnabled(this)) {
                Toast.makeText(this, R.string.need_access, Toast.LENGTH_LONG).show(); return
            }
            PermissionManager.requestNotificationsIfNeeded(this)
            startForegroundService(Intent(this, OverlayService::class.java))
        }
        window.decorView.postDelayed({ refreshStatus() }, 400)
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    private fun refreshStatus() {
        val ok = "✔"; val no = "✘"
        textStatus.text = "إذن الظهور فوق التطبيقات: ${if (PermissionManager.canDrawOverlays(this)) ok else no}\n" +
            "خدمة إمكانية الوصول: ${if (AccessibilityController.isServiceEnabled(this)) ok else no}\n" +
            "الدوائر العائمة: ${if (OverlayService.isRunning) ok else no}"
        btnToggle.setText(if (OverlayService.isRunning) R.string.btn_stop else R.string.btn_start)
    }
}
