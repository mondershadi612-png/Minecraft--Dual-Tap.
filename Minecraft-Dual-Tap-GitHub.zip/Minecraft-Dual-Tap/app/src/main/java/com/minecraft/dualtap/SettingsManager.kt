package com.minecraft.dualtap

import android.content.Context

/** Persists settings. Circle positions are stored as screen fractions (center point) so rotation works. */
class SettingsManager(context: Context) {
    private val p = context.applicationContext.getSharedPreferences("dualtap", Context.MODE_PRIVATE)

    var cps: Int
        get() = p.getInt("cps", 10)
        set(v) = p.edit().putInt("cps", v.coerceIn(1, 30)).apply()

    var sizeDp: Int
        get() = p.getInt("sizeDp", 64)
        set(v) = p.edit().putInt("sizeDp", v.coerceIn(40, 120)).apply()

    var alphaPct: Int
        get() = p.getInt("alphaPct", 70)
        set(v) = p.edit().putInt("alphaPct", v.coerceIn(20, 100)).apply()

    var visible: Boolean
        get() = p.getBoolean("visible", true)
        set(v) = p.edit().putBoolean("visible", v).apply()

    fun getPos(id: Int): Pair<Float, Float> =
        p.getFloat("fx$id", if (id == 0) 0.25f else 0.75f) to p.getFloat("fy$id", 0.5f)

    fun setPos(id: Int, fx: Float, fy: Float) {
        p.edit().putFloat("fx$id", fx).putFloat("fy$id", fy).apply()
    }

    fun resetPositions() {
        p.edit().remove("fx0").remove("fy0").remove("fx1").remove("fy1").apply()
    }
}
