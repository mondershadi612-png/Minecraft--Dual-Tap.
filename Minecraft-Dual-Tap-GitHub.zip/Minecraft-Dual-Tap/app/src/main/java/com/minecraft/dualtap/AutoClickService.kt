package com.minecraft.dualtap

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent

class AutoClickService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        AutoClickController.service = this
    }

    override fun onKeyEvent(event: KeyEvent): Boolean {
        val id = when (event.keyCode) {
            KeyEvent.KEYCODE_VOLUME_UP -> 0
            KeyEvent.KEYCODE_VOLUME_DOWN -> 1
            else -> return false
        }
        // Keep normal volume behavior unless the floating controls are enabled.
        if (!ClickManager.enabled) return false

        when (event.action) {
            KeyEvent.ACTION_DOWN -> if (event.repeatCount == 0) ClickManager.start(id)
            KeyEvent.ACTION_UP -> ClickManager.stop(id)
        }
        return true
    }

    /**
     * Dispatch both currently-held targets as strokes in ONE gesture.
     * Android may cancel an existing physical touch when an accessibility
     * gesture is injected; preserving Minecraft camera touch is device/game
     * dependent and cannot be guaranteed by an app-level implementation.
     */
    fun performTaps(points: List<Pair<Float, Float>>) {
        if (points.isEmpty()) return
        val builder = GestureDescription.Builder()
        points.forEach { (x, y) ->
            val path = Path().apply { moveTo(x, y) }
            builder.addStroke(GestureDescription.StrokeDescription(path, 0, 30))
        }
        dispatchGesture(builder.build(), null, null)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {
        ClickManager.stopAll()
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        ClickManager.stopAll()
        AutoClickController.service = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        ClickManager.stopAll()
        AutoClickController.service = null
        super.onDestroy()
    }
}
