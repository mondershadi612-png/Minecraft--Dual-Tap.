package com.minecraft.dualtap

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.os.Build
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager

class FloatingButton(
    context: Context,
    val id: Int,
    private val wm: WindowManager,
    private val settings: SettingsManager
) : View(context) {

    private val baseFlags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
        WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
        WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS

    private val lp = WindowManager.LayoutParams(
        0, 0, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, baseFlags, PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START }

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = Color.WHITE }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textAlign = Paint.Align.CENTER; isFakeBoldText = true }

    private var attached = false
    private var activeState = false
    private var downRawX = 0f; private var downRawY = 0f
    private var downX = 0; private var downY = 0

    private val sizePx get() = lp.width

    /** Center of the circle in absolute screen pixels. */
    fun centerOnScreen(): Pair<Float, Float> = (lp.x + sizePx / 2f) to (lp.y + sizePx / 2f)

    fun attach() {
        if (attached) return
        applySettings()
        wm.addView(this, lp)
        attached = true
    }

    fun detach() {
        if (!attached) return
        try { wm.removeView(this) } catch (_: Exception) {}
        attached = false
    }

    fun applySettings() {
        val size = (settings.sizeDp * resources.displayMetrics.density).toInt()
        lp.width = size; lp.height = size
        val (w, h) = screenSize()
        val (fx, fy) = settings.getPos(id)
        lp.x = (fx * w - size / 2f).toInt().coerceIn(0, (w - size).coerceAtLeast(0))
        lp.y = (fy * h - size / 2f).toInt().coerceIn(0, (h - size).coerceAtLeast(0))
        alpha = settings.alphaPct / 100f
        visibility = if (settings.visible) VISIBLE else GONE
        stroke.strokeWidth = size * 0.06f
        text.textSize = size * 0.4f
        if (attached) wm.updateViewLayout(this, lp)
        invalidate()
    }

    /** While clicking, let touches pass through the circle so the tap reaches the game underneath. */
    fun setActive(active: Boolean) {
        activeState = active
        lp.flags = if (active) baseFlags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE else baseFlags
        if (attached) wm.updateViewLayout(this, lp)
        invalidate()
    }

    @Suppress("DEPRECATION")
    private fun screenSize(): Pair<Int, Int> {
        if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.currentWindowMetrics.bounds
            return b.width() to b.height()
        }
        val dm = DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(dm)
        return dm.widthPixels to dm.heightPixels
    }

    override fun onDraw(canvas: Canvas) {
        val r = width / 2f
        fill.color = if (activeState) Color.parseColor("#2ECC71") else Color.parseColor("#3498DB")
        canvas.drawCircle(r, r, r - stroke.strokeWidth, fill)
        canvas.drawCircle(r, r, r - stroke.strokeWidth, stroke)
        canvas.drawText((id + 1).toString(), r, r - (text.descent() + text.ascent()) / 2f, text)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downRawX = e.rawX; downRawY = e.rawY; downX = lp.x; downY = lp.y
            }
            MotionEvent.ACTION_MOVE -> {
                val (w, h) = screenSize()
                lp.x = (downX + (e.rawX - downRawX)).toInt().coerceIn(0, (w - sizePx).coerceAtLeast(0))
                lp.y = (downY + (e.rawY - downRawY)).toInt().coerceIn(0, (h - sizePx).coerceAtLeast(0))
                wm.updateViewLayout(this, lp)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                val (w, h) = screenSize()
                val (cx, cy) = centerOnScreen()
                settings.setPos(id, cx / w, cy / h)
            }
        }
        return true
    }
}
