package com.minecraft.dualtap

import android.os.Handler
import android.os.Looper

/**
 * Two independent hold states, serviced by one scheduler.
 * Combining active points into one Accessibility gesture avoids one circle's
 * dispatchGesture call immediately cancelling the other circle's gesture.
 */
object ClickManager {
    private val handler = Handler(Looper.getMainLooper())
    private val active = BooleanArray(2)
    private var loop: Runnable? = null

    @Volatile var enabled = false
    @Volatile var intervalMs = 100L
    @Volatile var positionProvider: ((Int) -> Pair<Float, Float>?)? = null
    @Volatile var onStateChanged: ((Int, Boolean) -> Unit)? = null

    fun isActive(id: Int): Boolean = id in 0..1 && active[id]

    fun start(id: Int) {
        if (id !in 0..1 || !enabled || active[id]) return
        active[id] = true
        onStateChanged?.invoke(id, true)
        if (loop == null) {
            loop = object : Runnable {
                override fun run() {
                    if (!active.any { it }) {
                        loop = null
                        return
                    }
                    val points = buildList {
                        for (index in 0..1) {
                            if (active[index]) {
                                positionProvider?.invoke(index)?.let { add(it) }
                            }
                        }
                    }
                    if (points.isNotEmpty()) AutoClickController.tapAll(points)
                    handler.postDelayed(this, intervalMs.coerceAtLeast(33L))
                }
            }.also { handler.post(it) }
        }
    }

    fun stop(id: Int) {
        if (id !in 0..1 || !active[id]) return
        active[id] = false
        onStateChanged?.invoke(id, false)
        if (!active.any { it }) {
            loop?.let(handler::removeCallbacks)
            loop = null
        }
    }

    fun stopAll() {
        stop(0)
        stop(1)
    }
}
