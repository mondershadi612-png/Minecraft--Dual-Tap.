package com.minecraft.dualtap

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.os.Build
import android.os.IBinder
import android.view.WindowManager

class OverlayService : Service() {

    companion object {
        @Volatile var instance: OverlayService? = null
        private const val CHANNEL = "overlay"
        private const val NOTIF_ID = 1
        val isRunning get() = instance != null
    }

    private lateinit var settings: SettingsManager
    private lateinit var wm: WindowManager
    private val buttons = ArrayList<FloatingButton>()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        settings = SettingsManager(this)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        startAsForeground()

        if (!PermissionManager.canDrawOverlays(this)) { stopSelf(); return }

        for (id in 0..1) buttons.add(FloatingButton(this, id, wm, settings).also { it.attach() })

        ClickManager.positionProvider = { id -> buttons.getOrNull(id)?.centerOnScreen() }
        ClickManager.onStateChanged = { id, on -> buttons.getOrNull(id)?.setActive(on) }
        applySettings()
    }

    fun applySettings() {
        ClickManager.intervalMs = (1000L / settings.cps).coerceAtLeast(33L)
        ClickManager.enabled = settings.visible
        if (!settings.visible) ClickManager.stopAll()
        buttons.forEach { it.applySettings() }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        // Rotation / screen size change: recompute positions from saved fractions.
        buttons.forEach { it.post { it.applySettings() } }
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, getString(R.string.notif_channel), NotificationManager.IMPORTANCE_LOW)
        )
        val n: Notification = Notification.Builder(this, CHANNEL)
            .setContentTitle(getString(R.string.notif_title))
            .setContentText(getString(R.string.notif_text))
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    override fun onDestroy() {
        ClickManager.stopAll()
        ClickManager.enabled = false
        ClickManager.positionProvider = null
        ClickManager.onStateChanged = null
        buttons.forEach { it.detach() }
        buttons.clear()
        instance = null
        super.onDestroy()
    }
}
